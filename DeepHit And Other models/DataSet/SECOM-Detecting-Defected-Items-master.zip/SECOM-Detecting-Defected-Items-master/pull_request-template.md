# please take some beginner tutorials before jumping into it
# ignore the mounting of drve onto colaboratory if not using it.
